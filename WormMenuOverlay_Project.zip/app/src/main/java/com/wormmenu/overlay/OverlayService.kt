package com.wormmenu.overlay
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
class OverlayService: Service() {
 lateinit var wm:WindowManager; var root:View?=null; var expanded=false
 lateinit var lp:WindowManager.LayoutParams
 override fun onCreate(){ super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
 fun params()=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=24;y=180}
 fun install(v:View){ root=v; lp=params(); wm.addView(v,lp) }
 fun drag(v:View){ v.setOnTouchListener(object:View.OnTouchListener{var x=0;var y=0;var rx=0f;var ry=0f
 override fun onTouch(view:View,e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{x=lp.x;y=lp.y;rx=e.rawX;ry=e.rawY;return false};MotionEvent.ACTION_MOVE->{lp.x=x+(e.rawX-rx).toInt();lp.y=y+(e.rawY-ry).toInt();try{wm.updateViewLayout(root,lp)}catch(_:Exception){};return true}};return false}}) }
 fun showBubble(){ root?.let{try{wm.removeView(it)}catch(_:Exception){}}; val b=TextView(this).apply{text="W";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(170,0,0));setPadding(22,14,22,14);setOnClickListener{showPanel()} }; install(b);drag(b);expanded=false }
 fun showPanel(){root?.let{try{wm.removeView(it)}catch(_:Exception){}};val p=LinearLayout(this).apply{orientation=1;setPadding(16,14,16,14);setBackgroundColor(Color.rgb(18,18,18))}
 val h=TextView(this).apply{text="WORM MENU  ✕";textSize=18f;setTextColor(Color.RED);setPadding(8,8,8,16);setOnClickListener{showBubble()}}
 p.addView(h)
 listOf("ESP • تجريبي","AIMBOT • غير متصل","SPEED • غير متصل","SKIN • تجميلي","ANTI-AFK • غير متصل").forEach{label->p.addView(Button(this).apply{text=label;isAllCaps=false;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(110,0,0));setOnClickListener{Toast.makeText(this@OverlayService,"زر واجهة تجريبي فقط",Toast.LENGTH_SHORT).show()}})}
 p.addView(Button(this).apply{text="إغلاق";setOnClickListener{showBubble()}})
 root=p;lp=params().apply{width=280};wm.addView(p,lp);drag(p);expanded=true
 }
 override fun onDestroy(){root?.let{try{wm.removeView(it)}catch(_:Exception){}};super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}