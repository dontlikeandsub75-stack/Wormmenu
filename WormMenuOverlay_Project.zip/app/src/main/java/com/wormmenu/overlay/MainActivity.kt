package com.wormmenu.overlay
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val l=LinearLayout(this).apply { orientation=1; setPadding(30,50,30,30); setBackgroundColor(Color.rgb(18,18,18)) }
  l.addView(TextView(this).apply { text="WORM MENU • BLACK EDITION"; textSize=22f; setTextColor(Color.RED); setPadding(0,0,0,20) })
  l.addView(TextView(this).apply { text="واجهة عائمة تجريبية فوق التطبيقات. الأزرار لا تعدّل اللعبة."; textSize=16f; setTextColor(Color.WHITE); setPadding(0,0,0,20) })
  l.addView(Button(this).apply { text="السماح بالظهور فوق التطبيقات"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  l.addView(Button(this).apply { text="تشغيل WORM MENU"; setOnClickListener { if(Settings.canDrawOverlays(this@MainActivity)){ startService(Intent(this@MainActivity,OverlayService::class.java)); finish() } else Toast.makeText(this@MainActivity,"فعّل إذن الظهور فوق التطبيقات أولاً",Toast.LENGTH_LONG).show() } })
  setContentView(l)
 }
}