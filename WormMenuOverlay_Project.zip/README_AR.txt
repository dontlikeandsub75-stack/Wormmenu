WORM MENU BLACK EDITION - مشروع Android Studio

1) افتح هذا المجلد في Android Studio وانتظر Gradle Sync.
2) اختر Build > Build APK(s).
3) ثبّت APK الناتج.
4) افتح التطبيق وامنحه إذن الظهور فوق التطبيقات.
5) اضغط تشغيل، ثم افتح Null's Brawl.

هذه واجهة عائمة مستقلة فقط. لا تحقن كوداً في اللعبة ولا تنفذ ESP/Aimbot/Speed. قد تختلف خطوات الإذن حسب إصدار Android والشركة المصنّعة.
